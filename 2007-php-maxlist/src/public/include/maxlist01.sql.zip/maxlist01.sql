-- phpMyAdmin SQL Dump
-- version 2.11.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generato il: 31 Ott, 2007 at 07:40 
-- Versione MySQL: 5.0.45
-- Versione PHP: 5.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `maxlist01`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `default_admin`
--

CREATE TABLE IF NOT EXISTS `default_admin` (
  `id` int(11) NOT NULL auto_increment,
  `loginname` varchar(25) NOT NULL default '',
  `namelc` varchar(255) default NULL,
  `email` varchar(255) NOT NULL default '',
  `created` datetime default NULL,
  `modified` datetime default NULL,
  `modifiedby` varchar(25) default NULL,
  `password` varchar(255) default NULL,
  `passwordchanged` date default NULL,
  `superuser` tinyint(4) default '0',
  `disabled` tinyint(4) default '0',
  `role` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `loginname` (`loginname`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dump dei dati per la tabella `default_admin`
--

INSERT INTO `default_admin` (`id`, `loginname`, `namelc`, `email`, `created`, `modified`, `modifiedby`, `password`, `passwordchanged`, `superuser`, `disabled`, `role`) VALUES
(1, 'root', 'root', '', '2006-10-17 11:32:57', '2006-10-17 11:32:57', 'root', '63a9f0ea7bb98050796b649e85481845', '2006-10-17', 1, 0, 1),
(2, 'admin', 'admin', '', '2006-11-13 14:50:19', NULL, 'root', '21232f297a57a5a743894a0e4a801fc3', NULL, 0, 0, 2),
(8, 'simple', 'simple', '', '2006-12-03 19:33:22', NULL, 'root', '8dbdda48fb8748d6746f1965824e966a', NULL, 0, 0, 4),
(7, 'master', 'master', '', '2006-12-03 19:33:09', NULL, 'root', 'eb0a191797624dd3a48fa681d3061212', NULL, 0, 0, 3);

-- --------------------------------------------------------

--
-- Struttura della tabella `default_adminattribute`
--

CREATE TABLE IF NOT EXISTS `default_adminattribute` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `type` varchar(30) default NULL,
  `listorder` int(11) default NULL,
  `default_value` varchar(255) default NULL,
  `required` tinyint(4) default NULL,
  `tablename` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dump dei dati per la tabella `default_adminattribute`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_admin_attribute`
--

CREATE TABLE IF NOT EXISTS `default_admin_attribute` (
  `adminattributeid` int(11) NOT NULL default '0',
  `adminid` int(11) NOT NULL default '0',
  `value` varchar(255) default NULL,
  PRIMARY KEY  (`adminattributeid`,`adminid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `default_admin_attribute`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_attachment`
--

CREATE TABLE IF NOT EXISTS `default_attachment` (
  `id` int(11) NOT NULL auto_increment,
  `filename` varchar(255) default NULL,
  `remotefile` varchar(255) default NULL,
  `mimetype` varchar(255) default NULL,
  `description` text,
  `size` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dump dei dati per la tabella `default_attachment`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_bounce`
--

CREATE TABLE IF NOT EXISTS `default_bounce` (
  `id` int(11) NOT NULL auto_increment,
  `date` datetime default NULL,
  `header` text,
  `data` blob,
  `status` varchar(255) default NULL,
  `comment` text,
  PRIMARY KEY  (`id`),
  KEY `dateindex` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dump dei dati per la tabella `default_bounce`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_bounceregex`
--

CREATE TABLE IF NOT EXISTS `default_bounceregex` (
  `id` int(11) NOT NULL auto_increment,
  `regex` varchar(255) default NULL,
  `action` varchar(255) default NULL,
  `listorder` int(11) default '0',
  `admin` int(11) default NULL,
  `comment` text,
  `status` varchar(255) default NULL,
  `count` int(11) default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `regex` (`regex`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dump dei dati per la tabella `default_bounceregex`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_bounceregex_bounce`
--

CREATE TABLE IF NOT EXISTS `default_bounceregex_bounce` (
  `regex` int(11) NOT NULL default '0',
  `bounce` int(11) NOT NULL default '0',
  PRIMARY KEY  (`regex`,`bounce`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `default_bounceregex_bounce`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_config`
--

CREATE TABLE IF NOT EXISTS `default_config` (
  `item` varchar(35) NOT NULL default '',
  `value` longtext,
  `editable` tinyint(4) default '1',
  `type` varchar(25) default NULL,
  `role` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`item`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `default_config`
--

INSERT INTO `default_config` (`item`, `value`, `editable`, `type`, `role`) VALUES
('xormask', 'c1629903f0a409315703ecd2a0e39c0b', 0, NULL, 1),
('defaultmessagetemplate', '1', 1, NULL, 1),
('domain', 'maxlist.net', 0, NULL, 1),
('website', 'maxlist.maxbnet', 0, NULL, 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `default_eventlog`
--

CREATE TABLE IF NOT EXISTS `default_eventlog` (
  `id` int(11) NOT NULL auto_increment,
  `entered` datetime default NULL,
  `page` varchar(100) default NULL,
  `entry` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dump dei dati per la tabella `default_eventlog`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_linktrack`
--

CREATE TABLE IF NOT EXISTS `default_linktrack` (
  `linkid` int(11) NOT NULL auto_increment,
  `messageid` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  `url` varchar(255) default NULL,
  `forward` text,
  `firstclick` datetime default NULL,
  `latestclick` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `clicked` int(11) default '0',
  PRIMARY KEY  (`linkid`),
  UNIQUE KEY `messageid` (`messageid`,`userid`,`url`),
  KEY `miduidurlindex` (`messageid`,`userid`,`url`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dump dei dati per la tabella `default_linktrack`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_linktrack_userclick`
--

CREATE TABLE IF NOT EXISTS `default_linktrack_userclick` (
  `linkid` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  `messageid` int(11) NOT NULL default '0',
  `name` varchar(255) default NULL,
  `data` text,
  `date` datetime default NULL,
  KEY `linkusermessageindex` (`linkid`,`userid`,`messageid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `default_linktrack_userclick`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_list`
--

CREATE TABLE IF NOT EXISTS `default_list` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `description` text,
  `entered` datetime default NULL,
  `listorder` int(11) default NULL,
  `prefix` varchar(10) default NULL,
  `modified` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `active` tinyint(4) default NULL,
  `owner` int(11) default NULL,
  `rssfeed` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dump dei dati per la tabella `default_list`
--

INSERT INTO `default_list` (`id`, `name`, `description`, `entered`, `listorder`, `prefix`, `modified`, `active`, `owner`, `rssfeed`) VALUES
(1, 'test', 'test', '2006-12-03 13:23:45', 1, '', '2006-12-03 13:23:45', 1, 2, '');

-- --------------------------------------------------------

--
-- Struttura della tabella `default_listmessage`
--

CREATE TABLE IF NOT EXISTS `default_listmessage` (
  `id` int(11) NOT NULL auto_increment,
  `messageid` int(11) NOT NULL default '0',
  `listid` int(11) NOT NULL default '0',
  `entered` datetime default NULL,
  `modified` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `messageid` (`messageid`,`listid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dump dei dati per la tabella `default_listmessage`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_listuser`
--

CREATE TABLE IF NOT EXISTS `default_listuser` (
  `userid` int(11) NOT NULL default '0',
  `listid` int(11) NOT NULL default '0',
  `entered` datetime default NULL,
  `modified` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`userid`,`listid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `default_listuser`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_message`
--

CREATE TABLE IF NOT EXISTS `default_message` (
  `id` int(11) NOT NULL auto_increment,
  `subject` varchar(255) NOT NULL default '',
  `fromfield` varchar(255) NOT NULL default '',
  `tofield` varchar(255) NOT NULL default '',
  `replyto` varchar(255) NOT NULL default '',
  `message` text,
  `footer` text,
  `entered` datetime default NULL,
  `modified` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `status` varchar(255) default NULL,
  `processed` mediumint(8) unsigned default '0',
  `userselection` text,
  `sent` datetime default NULL,
  `htmlformatted` tinyint(4) default '0',
  `sendformat` varchar(20) default NULL,
  `template` int(11) default NULL,
  `astext` int(11) default '0',
  `ashtml` int(11) default '0',
  `astextandhtml` int(11) default '0',
  `viewed` int(11) default '0',
  `bouncecount` int(11) default '0',
  `sendstart` datetime default NULL,
  `aspdf` int(11) default '0',
  `astextandpdf` int(11) default '0',
  `rsstemplate` varchar(100) default NULL,
  `owner` int(11) default NULL,
  `embargo` datetime default NULL,
  `repeatinterval` int(11) default '0',
  `repeatuntil` datetime default NULL,
  `textmessage` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dump dei dati per la tabella `default_message`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_messagedata`
--

CREATE TABLE IF NOT EXISTS `default_messagedata` (
  `name` varchar(100) NOT NULL default '',
  `id` int(11) NOT NULL default '0',
  `data` text,
  PRIMARY KEY  (`name`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `default_messagedata`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_message_attachment`
--

CREATE TABLE IF NOT EXISTS `default_message_attachment` (
  `id` int(11) NOT NULL auto_increment,
  `messageid` int(11) NOT NULL default '0',
  `attachmentid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dump dei dati per la tabella `default_message_attachment`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_sendprocess`
--

CREATE TABLE IF NOT EXISTS `default_sendprocess` (
  `id` int(11) NOT NULL auto_increment,
  `started` datetime default NULL,
  `modified` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `alive` int(11) default '1',
  `ipaddress` varchar(50) default NULL,
  `page` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=185 ;

--
-- Dump dei dati per la tabella `default_sendprocess`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_subscribepage`
--

CREATE TABLE IF NOT EXISTS `default_subscribepage` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `active` tinyint(4) default '0',
  `owner` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dump dei dati per la tabella `default_subscribepage`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_subscribepage_data`
--

CREATE TABLE IF NOT EXISTS `default_subscribepage_data` (
  `id` int(11) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `data` text,
  PRIMARY KEY  (`id`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `default_subscribepage_data`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_template`
--

CREATE TABLE IF NOT EXISTS `default_template` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `template` longblob,
  `listorder` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dump dei dati per la tabella `default_template`
--

INSERT INTO `default_template` (`id`, `title`, `template`, `listorder`) VALUES
(1, 'tracking', 0x5b434f4e54454e545d0d0a0d0a5b55534552545241434b5d, NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `default_templateimage`
--

CREATE TABLE IF NOT EXISTS `default_templateimage` (
  `id` int(11) NOT NULL auto_increment,
  `template` int(11) default NULL,
  `mimetype` varchar(100) default NULL,
  `filename` varchar(100) default NULL,
  `data` longblob,
  `width` int(11) default NULL,
  `height` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dump dei dati per la tabella `default_templateimage`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_urlcache`
--

CREATE TABLE IF NOT EXISTS `default_urlcache` (
  `id` int(11) NOT NULL auto_increment,
  `url` varchar(255) NOT NULL default '',
  `lastmodified` int(11) default NULL,
  `added` datetime default NULL,
  `content` mediumtext,
  PRIMARY KEY  (`id`),
  KEY `urlindex` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dump dei dati per la tabella `default_urlcache`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_usermessage`
--

CREATE TABLE IF NOT EXISTS `default_usermessage` (
  `messageid` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  `entered` datetime default NULL,
  `viewed` datetime default NULL,
  `status` varchar(255) default NULL,
  PRIMARY KEY  (`userid`,`messageid`),
  KEY `userindex` (`userid`),
  KEY `messageindex` (`messageid`),
  KEY `enteredindex` (`entered`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `default_usermessage`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_userstats`
--

CREATE TABLE IF NOT EXISTS `default_userstats` (
  `id` int(11) NOT NULL auto_increment,
  `unixdate` int(11) default NULL,
  `item` varchar(255) default NULL,
  `listid` int(11) default '0',
  `value` int(11) default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `entry` (`unixdate`,`item`,`listid`),
  KEY `listdateindex` (`listid`,`unixdate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dump dei dati per la tabella `default_userstats`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_user_attribute`
--

CREATE TABLE IF NOT EXISTS `default_user_attribute` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `type` varchar(30) default NULL,
  `listorder` int(11) default NULL,
  `default_value` varchar(255) default NULL,
  `required` tinyint(4) default NULL,
  `tablename` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dump dei dati per la tabella `default_user_attribute`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_user_blacklist`
--

CREATE TABLE IF NOT EXISTS `default_user_blacklist` (
  `email` varchar(255) NOT NULL default '',
  `added` datetime default NULL,
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `default_user_blacklist`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_user_blacklist_data`
--

CREATE TABLE IF NOT EXISTS `default_user_blacklist_data` (
  `email` varchar(255) NOT NULL default '',
  `name` varchar(100) default NULL,
  `data` text,
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `default_user_blacklist_data`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_user_message_bounce`
--

CREATE TABLE IF NOT EXISTS `default_user_message_bounce` (
  `id` int(11) NOT NULL auto_increment,
  `user` int(11) NOT NULL default '0',
  `message` int(11) NOT NULL default '0',
  `bounce` int(11) NOT NULL default '0',
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  KEY `user` (`user`,`message`,`bounce`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dump dei dati per la tabella `default_user_message_bounce`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_user_message_forward`
--

CREATE TABLE IF NOT EXISTS `default_user_message_forward` (
  `id` int(11) NOT NULL auto_increment,
  `user` int(11) NOT NULL default '0',
  `message` int(11) NOT NULL default '0',
  `forward` varchar(255) default NULL,
  `status` varchar(255) default NULL,
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  KEY `user` (`user`,`message`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dump dei dati per la tabella `default_user_message_forward`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_user_rss`
--

CREATE TABLE IF NOT EXISTS `default_user_rss` (
  `userid` int(11) NOT NULL default '0',
  `last` datetime default NULL,
  PRIMARY KEY  (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `default_user_rss`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_user_user`
--

CREATE TABLE IF NOT EXISTS `default_user_user` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(255) NOT NULL default '',
  `confirmed` tinyint(4) default '0',
  `entered` datetime default NULL,
  `modified` datetime default NULL,
  `uniqid` varchar(255) default NULL,
  `htmlemail` tinyint(4) default '0',
  `bouncecount` int(11) default '0',
  `subscribepage` int(11) default '0',
  `rssfrequency` varchar(100) default NULL,
  `password` varchar(255) default NULL,
  `passwordchanged` datetime default NULL,
  `disabled` tinyint(4) default '0',
  `extradata` text,
  `foreignkey` varchar(100) default NULL,
  `blacklisted` tinyint(4) default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `fkey` (`foreignkey`),
  KEY `index_uniqid` (`uniqid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dump dei dati per la tabella `default_user_user`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_user_user_attribute`
--

CREATE TABLE IF NOT EXISTS `default_user_user_attribute` (
  `attributeid` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  `value` varchar(255) default NULL,
  PRIMARY KEY  (`attributeid`,`userid`),
  KEY `userindex` (`userid`),
  KEY `attindex` (`attributeid`),
  KEY `userattid` (`attributeid`,`userid`),
  KEY `attuserid` (`userid`,`attributeid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `default_user_user_attribute`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `default_user_user_history`
--

CREATE TABLE IF NOT EXISTS `default_user_user_history` (
  `id` int(11) NOT NULL auto_increment,
  `userid` int(11) NOT NULL default '0',
  `ip` varchar(255) default NULL,
  `date` datetime default NULL,
  `summary` varchar(255) default NULL,
  `detail` text,
  `systeminfo` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dump dei dati per la tabella `default_user_user_history`
--


-- --------------------------------------------------------

--
-- Struttura della tabella `maxlist_istances`
--

CREATE TABLE IF NOT EXISTS `maxlist_istances` (
  `id_istance` bigint(20) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id_istance`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dump dei dati per la tabella `maxlist_istances`
--

INSERT INTO `maxlist_istances` (`id_istance`, `name`) VALUES
(1, 'default');
